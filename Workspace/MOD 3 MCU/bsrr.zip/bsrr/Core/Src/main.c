#include"main.h"
void delay(int T)
{
	int i;
	while(T--)
	{
	for(i=0;i<4000;i++);
	}
}
int main()
{
	RCC->AHB1ENR |= 0x7;
	GPIOA->MODER |= 0x400;
	while(1){
		GPIOA->BSRR |= 0x20;
		delay(100);
		GPIOA->BSRR |= ~(0x20);
		delay(100);
}
}
HAL_Toggle
