/*
 * all.h
 *
 *  Created on: Apr 25, 2023
 *      Author: PHY202302EF11
 */

#ifndef ALL_H_
#define ALL_H_

void delay(int T);
void UART2_Init(void);
int __io_putchar(unsigned char ch);
void Usart2_Transmit(unsigned char ch);

#endif /* ALL_H_ */
